# "BUYUK" botcular. 

Bana türeme altyapı kullanıyor vb. gibi şeyler söyleyen kardeşlerimin botlarını paylaşma kararı aldım. Kahpeliğin hazinli sonu bu olsa gerek. Köpekler gibi bot isterken "botcuyduk" şimdi altyapı kullanan türememi olduk ? Alın size altyapı. Star atma atıyom kullanırsın. 

[![Discord Presence](https://lanyard-profile-readme.vercel.app/api/482541644944506880)](https://discord.com/users/482541644944506880)
